<?php

return array(
	array(
		'username'=>'neo',
		'password'=>'$2y$10$6q8D2lv/K73HNcDoEs01.ODNfLq7Wz/EzoAwtOJ4R8bUmCOujW4ky',
		'password_set_on' => '2011-11-11 12:34',
		'email'=>'neo@matrix.com',
		'is_active'=>1,
		'is_disabled'=>0,
	),
	array(
		'username'=>'tank',
		'password'=>'$2y$10$6q8D2lv/K73HNcDoEs01.ODNfLq7Wz/EzoAwtOJ4R8bUmCOujW4ky',
		'password_set_on' => '2012-12-12 10:00',
		'email'=>'tank@matrix.com',
		'is_active'=>0,
		'is_disabled'=>1,
	),
	array(
		'username'=>'smith',
		'password'=>'xx',
		'email'=>'smith@matrix.com',
		'is_active'=>0,
		'is_disabled'=>1,
	),
	array(
		'username'=>'cat',
		'password'=>'xx',
		'email'=>'cat@matrix.com',
		'is_active'=>1,
		'is_disabled'=>0,
	),
);

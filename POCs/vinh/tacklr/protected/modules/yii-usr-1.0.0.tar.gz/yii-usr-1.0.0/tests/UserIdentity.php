<?php

Yii::import('vendors.nineinchnick.yii-usr.components.ExampleUserIdentity');

class UserIdentity extends ExampleUserIdentity
{
}

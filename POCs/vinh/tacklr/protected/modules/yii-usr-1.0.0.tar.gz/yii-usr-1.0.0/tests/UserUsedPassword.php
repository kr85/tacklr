<?php

Yii::import('vendors.nineinchnick.yii-usr.models.ExampleUserUsedPassword');

class UserUsedPassword extends ExampleUserUsedPassword
{
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
